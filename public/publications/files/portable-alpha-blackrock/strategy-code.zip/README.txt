Portable Alpha & Return Stacking Prototype (YAMF Research)
===========================================================
Run:
    uv run --with yfinance --with pandas --with numpy --with scikit-learn --with matplotlib python3 portable_alpha_prototype.py

Contents:
- portable_alpha_prototype.py : Full data loader, EWMA trend & global macro engines, vol targeting, and validation
- summary_metrics.json        : Exact summary statistics exported from the 2008-11 to 2026-11 backtest
