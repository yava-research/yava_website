"""
Reproducible Portable Alpha & Return Stacking Research Prototype
----------------------------------------------------------------
Tests signal logic (EWMA trend, TSMOM, Global Macro regime/carry),
Macro/Trend blend weights, 4-asset-class behavior, 70/30 Bottom-Up /
Top-Down CTA replication, and live DBMF / KMLM / RSIT validation
using Yahoo Finance daily total-return data (2007-10 to 2026-11).
"""

import os
import json
import zipfile
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import yfinance as yf
from sklearn.linear_model import Ridge

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter

# ==============================================================================
# CONFIGURATION & UNIVERSE
# ==============================================================================
ASSET_CLASSES = {
    "Equities": ["SPY", "VGK", "EWJ", "EEM"],
    "Rates": ["SHY", "IEF", "TLT", "BWX"],
    "FX": ["FXE", "FXY", "FXB", "FXA"],
    "Commodities": ["GLD", "SLV", "USO", "DBA"],
}
OVERLAY_TICKERS = [t for lst in ASSET_CLASSES.values() for t in lst]
AUX_TICKERS = [
    "EFA", "AGG", "BIL", "TIP", "HYG", "DBC",
    "^IRX", "^TNX", "^VIX", "HG=F", "GC=F",
    "EURUSD=X", "JPY=X", "GBPUSD=X", "AUDUSD=X",
    "DBMF", "KMLM", "RSST", "RSIT",
]
ALL_TICKERS = sorted(set(OVERLAY_TICKERS + AUX_TICKERS))

CACHE_PATH = "/tmp/yf_portable_alpha_v2.csv"
EVAL_START = "2008-11-03"
FIN_SPREAD_ANNUAL = 0.0040   # 40 bps/yr equity futures implied financing spread
TC_ONEWAY_BPS = 5.0          # 5 bps one-way (10 bps round-trip) futures slippage
TARGET_VOL = 0.10            # 10% annualized target vol for alpha overlay

OUT_PUB = "public/publications"
OUT_FILES = "public/publications/files/portable-alpha-blackrock"
os.makedirs(OUT_FILES, exist_ok=True)

# ==============================================================================
# 1. LOAD & ALIGN DATA TO NYSE EQUITY CALENDAR
# ==============================================================================
if os.path.exists(CACHE_PATH):
    raw = pd.read_csv(CACHE_PATH, index_col=0, parse_dates=True)
else:
    raw = yf.download(
        ALL_TICKERS, start="2007-06-01", end="2026-11-22",
        auto_adjust=True, progress=False
    )["Close"]
    raw.to_csv(CACHE_PATH)

nyse_dates = raw[["EFA", "SPY", "AGG", "BIL"]].dropna().index
raw_nyse = raw.ffill().reindex(nyse_dates)

CORE_REQ = OVERLAY_TICKERS + [
    "EFA", "AGG", "BIL", "TIP", "HYG", "DBC",
    "^IRX", "^TNX", "^VIX", "HG=F", "GC=F",
]
df = raw_nyse[CORE_REQ].dropna()
rets = df.pct_change().fillna(0.0)
rf = rets["BIL"]

# Unfunded futures excess return proxy: R_ETF - R_BIL
xs = rets[OVERLAY_TICKERS].sub(rf, axis=0)

# EWMA realized volatility (42d span, floored at 2.5% to bound short-rate leverage)
vol_ann = (xs.ewm(span=42, min_periods=20).std() * np.sqrt(252)).clip(lower=0.025)
xs_idx = (1.0 + xs).cumprod()
log_px = np.log(xs_idx)

# ==============================================================================
# 2. SIGNAL ENGINES
# ==============================================================================
# A. Systematic Trend: Multi-Horizon EWMA Crossover
ewma_pairs = [(16, 64), (32, 128), (64, 256)]
ewma_wts = [0.25, 0.40, 0.35]
sig_trend_ewma = pd.DataFrame(0.0, index=df.index, columns=OVERLAY_TICKERS)
for (fast, slow), w in zip(ewma_pairs, ewma_wts):
    diff = log_px.ewm(span=fast).mean() - log_px.ewm(span=slow).mean()
    norm = diff / ((vol_ann / np.sqrt(252)) * np.sqrt(slow / 2.0))
    sig_trend_ewma = sig_trend_ewma + w * np.tanh(norm / 1.2)

tsmom_horizons = [(21, 0.15), (63, 0.25), (126, 0.30), (252, 0.30)]
sig_trend_tsmom = sum(
    w * np.tanh((log_px.diff(h) / ((vol_ann / np.sqrt(252)) * np.sqrt(h))) / 1.2)
    for h, w in tsmom_horizons
)
sig_trend_binary = sum(w * np.sign(log_px.diff(h)) for h, w in tsmom_horizons)

# B. Global Macro: Growth + Inflation + Yield-Curve Carry + Implied FX Carry
cu_au = np.log(df["HG=F"] / df["GC=F"])
cu_au_z = (cu_au.diff(63) / (cu_au.diff().ewm(span=63).std() * np.sqrt(63))).clip(-3, 3)
hy_ief = np.log(df["HYG"] / df["IEF"])
hy_ief_z = (hy_ief.diff(63) / (hy_ief.diff().ewm(span=63).std() * np.sqrt(63))).clip(-3, 3)
growth_pulse = 0.50 * cu_au_z + 0.50 * hy_ief_z

tip_ief = np.log(df["TIP"] / df["IEF"])
tip_z = (tip_ief.diff(63) / (tip_ief.diff().ewm(span=63).std() * np.sqrt(63))).clip(-3, 3)
dbc_lp = np.log(df["DBC"])
dbc_z = (dbc_lp.diff(126) / (dbc_lp.diff().ewm(span=63).std() * np.sqrt(126))).clip(-3, 3)
infl_pulse = 0.50 * tip_z + 0.50 * dbc_z

slope = df["^TNX"] - df["^IRX"]
curve_carry = np.tanh((slope - 0.50) / 1.50)
tnx_chg = (df["^TNX"].diff(126) / (df["^TNX"].diff().ewm(span=63).std() * np.sqrt(126))).clip(-3, 3)

fx_carry = pd.DataFrame(0.0, index=df.index, columns=["FXE", "FXY", "FXB", "FXA"])
fx_spot_map = {"FXE": ("EURUSD=X", 1), "FXY": ("JPY=X", -1), "FXB": ("GBPUSD=X", 1), "FXA": ("AUDUSD=X", 1)}
for etf, (spot_tkr, sign) in fx_spot_map.items():
    spot_s = raw_nyse[spot_tkr].reindex(df.index).ffill()
    etf_6m = np.log(df[etf] / df[etf].shift(126))
    spot_6m = sign * np.log(spot_s / spot_s.shift(126))
    usd_6m = np.log(df["BIL"] / df["BIL"].shift(126))
    imp_carry_ann = (etf_6m - spot_6m - usd_6m) * 2.0
    fx_carry[etf] = np.tanh(imp_carry_ann.clip(-0.08, 0.08) / 0.025)

sig_macro = pd.DataFrame(0.0, index=df.index, columns=OVERLAY_TICKERS)
for t in ASSET_CLASSES["Equities"]:
    sig_macro[t] = np.tanh((0.65 * growth_pulse - 0.35 * tnx_chg) / 1.2)
for t in ASSET_CLASSES["Rates"]:
    sig_macro[t] = np.tanh((0.30 * curve_carry - 0.35 * infl_pulse - 0.35 * tnx_chg) / 1.1)
for t in ["FXE", "FXB", "FXA"]:
    sig_macro[t] = np.tanh((0.40 * fx_carry[t] + 0.30 * growth_pulse - 0.30 * tnx_chg) / 1.0)
sig_macro["FXY"] = np.tanh((0.40 * fx_carry["FXY"] - 0.25 * growth_pulse - 0.35 * tnx_chg) / 1.0)
for t in ["GLD", "SLV"]:
    sig_macro[t] = np.tanh((0.55 * infl_pulse - 0.45 * tnx_chg) / 1.1)
for t in ["USO", "DBA"]:
    sig_macro[t] = np.tanh((0.60 * infl_pulse + 0.40 * growth_pulse) / 1.1)

# ==============================================================================
# 3. VOLATILITY-TARGETED PORTFOLIO ENGINE
# ==============================================================================
def run_overlay(signal_df: pd.DataFrame, target_vol: float = TARGET_VOL,
                tc_oneway_bps: float = TC_ONEWAY_BPS, max_gross: float = 4.0):
    raw_w = pd.DataFrame(0.0, index=signal_df.index, columns=OVERLAY_TICKERS)
    for cls, tickers in ASSET_CLASSES.items():
        inv_vol = 1.0 / vol_ann[tickers]
        raw_w[tickers] = signal_df[tickers] * inv_vol * (0.25 / len(tickers)) * target_vol * 2.5

    rebal_dates = signal_df.groupby(signal_df.index.to_period("W")).tail(1).index
    is_rebal = signal_df.index.isin(rebal_dates)
    w_sched = raw_w.loc[is_rebal].reindex(signal_df.index).ffill().fillna(0.0)

    lag_raw = w_sched.shift(1).fillna(0.0)
    raw_ret = (lag_raw * xs).sum(axis=1)
    realized_vol = (raw_ret.ewm(span=42, min_periods=21).std() * np.sqrt(252)).shift(1)
    vol_mult = (target_vol / realized_vol.replace(0, np.nan)).clip(0.35, 3.0).fillna(1.0)
    vol_mult_sched = vol_mult.loc[is_rebal].reindex(signal_df.index).ffill().fillna(1.0)

    w_final = w_sched.mul(vol_mult_sched, axis=0)
    gross = w_final.abs().sum(axis=1)
    cap_mult = np.minimum(1.0, max_gross / gross.replace(0, np.nan)).fillna(1.0)
    w_final = w_final.mul(cap_mult, axis=0)

    w_exec = w_final.shift(1).fillna(0.0)
    gross_ret = (w_exec * xs).sum(axis=1)
    turnover = w_exec.diff().abs().sum(axis=1).fillna(0.0)
    net_ret = gross_ret - turnover * (tc_oneway_bps / 10000.0)

    cls_contrib = pd.DataFrame({
        cls: (w_exec[tickers] * xs[tickers]).sum(axis=1)
        for cls, tickers in ASSET_CLASSES.items()
    })
    return {
        "gross_ret": gross_ret, "net_ret": net_ret,
        "weights": w_exec, "turnover": turnover, "cls_contrib": cls_contrib,
    }

def calc_stats(r: pd.Series, rf_s: pd.Series, bench: pd.Series = None):
    r = r.dropna()
    rf_s = rf_s.loc[r.index]
    n_yr = len(r) / 252.0
    cagr = (1.0 + r).prod() ** (1.0 / n_yr) - 1.0
    vol = r.std() * np.sqrt(252)
    ex = r - rf_s
    sharpe = (ex.mean() * 252) / (ex.std() * np.sqrt(252)) if ex.std() > 0 else 0.0
    down = ex[ex < 0].std() * np.sqrt(252)
    sortino = (ex.mean() * 252) / down if down > 0 else 0.0
    nav = (1.0 + r).cumprod()
    mdd = (nav / nav.cummax() - 1.0).min()
    calmar = cagr / abs(mdd) if mdd < 0 else 0.0
    corr = float(r.corr(bench.loc[r.index])) if bench is not None else np.nan
    return {
        "cagr_pct": round(cagr * 100, 2),
        "vol_pct": round(vol * 100, 2),
        "sharpe": round(sharpe, 2),
        "sortino": round(sortino, 2),
        "mdd_pct": round(mdd * 100, 2),
        "calmar": round(calmar, 2),
        "corr_efa": round(corr, 2),
    }

# ==============================================================================
# 4. RUN CORE BACKTESTS & SWEEP
# ==============================================================================
efa_r = rets.loc[EVAL_START:, "EFA"]
spy_r = rets.loc[EVAL_START:, "SPY"]
agg_r = rets.loc[EVAL_START:, "AGG"]
rf_r = rf.loc[EVAL_START:]
fin_daily = FIN_SPREAD_ANNUAL / 252.0

res_trend = run_overlay(sig_trend_ewma)
res_macro = run_overlay(sig_macro)
res_blend = run_overlay(0.60 * sig_trend_ewma + 0.40 * sig_macro)

ov_trend = res_trend["net_ret"].loc[EVAL_START:]
ov_macro = res_macro["net_ret"].loc[EVAL_START:]
ov_blend = res_blend["net_ret"].loc[EVAL_START:]

port_6040 = 0.60 * efa_r + 0.40 * agg_r
port_split = 0.50 * efa_r + 0.50 * (ov_blend + rf_r)
port_stk_trend = efa_r + ov_trend - fin_daily
port_stk_blend = efa_r + ov_blend - fin_daily

# Sweep macro weights
sweep_grid = []
for w_m in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1.0]:
    w_t = round(1.0 - w_m, 2)
    r_sw = run_overlay(w_t * sig_trend_ewma + w_m * sig_macro)["net_ret"].loc[EVAL_START:]
    stk_sw = efa_r + r_sw - fin_daily
    st_o = calc_stats(r_sw + rf_r, rf_r, efa_r)
    st_s = calc_stats(stk_sw, rf_r, efa_r)
    efa_m = (1 + efa_r).resample("ME").prod() - 1
    ov_m = (1 + r_sw).resample("ME").prod() - 1
    ca = ov_m[efa_m <= efa_m.quantile(0.10)].mean() * 100
    sweep_grid.append({
        "macro_pct": int(round(w_m * 100)),
        "trend_pct": int(round(w_t * 100)),
        "ov_xs_pct": round(((1 + r_sw).prod() ** (252 / len(r_sw)) - 1) * 100, 2),
        "ov_vol_pct": st_o["vol_pct"],
        "ov_sharpe": st_o["sharpe"],
        "ov_mdd_pct": st_o["mdd_pct"],
        "corr_efa": st_o["corr_efa"],
        "crisis_alpha_m_pct": round(ca, 2),
        "stk_cagr_pct": st_s["cagr_pct"],
        "stk_vol_pct": st_s["vol_pct"],
        "stk_sharpe": st_s["sharpe"],
        "stk_mdd_pct": st_s["mdd_pct"],
    })
sweep_df = pd.DataFrame(sweep_grid)

# ==============================================================================
# 5. EXPORT CSV & SUMMARY JSON & ZIP
# ==============================================================================
nav_df = pd.DataFrame({
    "EFA_ret": efa_r,
    "SPY_ret": spy_r,
    "EFA60_AGG40_ret": port_6040,
    "Split5050_ret": port_split,
    "Overlay_Trend_xs": ov_trend,
    "Overlay_Macro_xs": ov_macro,
    "Overlay_Blend6040_xs": ov_blend,
    "Stacked_PureTrend_ret": port_stk_trend,
    "Stacked_Blend6040_ret": port_stk_blend,
    "BIL_rf_ret": rf_r,
    "Contrib_Equities": res_blend["cls_contrib"].loc[EVAL_START:, "Equities"],
    "Contrib_Rates": res_blend["cls_contrib"].loc[EVAL_START:, "Rates"],
    "Contrib_FX": res_blend["cls_contrib"].loc[EVAL_START:, "FX"],
    "Contrib_Commodities": res_blend["cls_contrib"].loc[EVAL_START:, "Commodities"],
    "Overlay_GrossLeverage": res_blend["weights"].loc[EVAL_START:].abs().sum(axis=1),
    "Overlay_Turnover": res_blend["turnover"].loc[EVAL_START:],
})
for col, r_col in [
    ("NAV_EFA", efa_r),
    ("NAV_EFA60_AGG40", port_6040),
    ("NAV_Split5050", port_split),
    ("NAV_Stacked_PureTrend", port_stk_trend),
    ("NAV_Stacked_Blend6040", port_stk_blend),
]:
    nav_df[col] = 100.0 * (1.0 + r_col).cumprod()

csv_path = os.path.join(OUT_FILES, "backtest-results.csv")
nav_df.round(6).to_csv(csv_path, index_label="Date")

# Summary metrics for JSON + inline chart milestones (8 clean points)
milestones = ["2008-11-03", "2011-12-30", "2014-12-31", "2017-12-29", "2020-12-31", "2022-12-30", "2024-12-31", "2026-11-20"]
ms_rows = []
for dt_str in milestones:
    dt = nav_df.index[nav_df.index.get_indexer([pd.Timestamp(dt_str)], method="pad")[0]]
    row = nav_df.loc[dt]
    ms_rows.append({
        "period": dt.strftime("%b %y") if dt_str in ("2008-11-03", "2026-11-20") else dt.strftime("%Y"),
        "stacked": round(float(row["NAV_Stacked_Blend6040"]), 1),
        "efa": round(float(row["NAV_EFA"]), 1),
        "split5050": round(float(row["NAV_Split5050"]), 1),
        "efa6040": round(float(row["NAV_EFA60_AGG40"]), 1),
    })

summary = {
    "sample_start": str(efa_r.index[0].date()),
    "sample_end": str(efa_r.index[-1].date()),
    "trading_days": int(len(efa_r)),
    "milestones_nav": ms_rows,
    "portfolios": {
        "EFA": calc_stats(efa_r, rf_r, efa_r),
        "SPY": calc_stats(spy_r, rf_r, efa_r),
        "EFA60_AGG40": calc_stats(port_6040, rf_r, efa_r),
        "Split5050": calc_stats(port_split, rf_r, efa_r),
        "Stacked_PureTrend": calc_stats(port_stk_trend, rf_r, efa_r),
        "Stacked_Blend6040": calc_stats(port_stk_blend, rf_r, efa_r),
    },
    "sweep": sweep_grid,
}
json_path = "/tmp/portable_alpha_summary.json"
with open(json_path, "w") as f:
    json.dump(summary, f, indent=2)

# Build reproducible ZIP archive
readme_txt = """Portable Alpha & Return Stacking Prototype (YAMF Research)
===========================================================
Run:
    uv run --with yfinance --with pandas --with numpy --with scikit-learn --with matplotlib python3 portable_alpha_prototype.py

Contents:
- portable_alpha_prototype.py : Full data loader, EWMA trend & global macro engines, vol targeting, and validation
- summary_metrics.json        : Exact summary statistics exported from the 2008-11 to 2026-11 backtest
"""
zip_path = os.path.join(OUT_FILES, "strategy-code.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    zf.write(__file__, arcname="portable_alpha_prototype.py")
    zf.write(json_path, arcname="summary_metrics.json")
    zf.writestr("README.txt", readme_txt)

print("Milestones for interactive LineChartCard:")
print(json.dumps(ms_rows, indent=2))

# ==============================================================================
# 6. SONORAN EDITORIAL SVG EXHIBITS (YAMF DESIGN PALETTE)
# ==============================================================================
NAVY = "#00043A"
NIGHT = "#141A63"
PAPER = "#FFFDF9"
SAND = "#F6F1E8"
SAND2 = "#ECE3D4"
SANDSTONE = "#C9A57A"
OCHRE = "#80603D"
SAGE = "#5F6B52"
RUST = "#8F3F30"
BORDER = "#D8CCB8"
MUTED = "#6B6A7E"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Fira Sans", "Helvetica Neue", "DejaVu Sans"],
    "axes.edgecolor": BORDER,
    "axes.linewidth": 0.9,
    "figure.facecolor": PAPER,
    "axes.facecolor": PAPER,
    "text.color": NAVY,
    "axes.labelcolor": NAVY,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "svg.fonttype": "none",
    "path.simplify": True,
    "path.simplify_threshold": 0.8,
})

# --- EXHIBIT 1: Cumulative Wealth & Drawdowns (portable-alpha-backtest.svg) ---
fig, (ax1, ax2) = plt.subplots(
    2, 1, figsize=(11.2, 6.4), sharex=True,
    gridspec_kw={"height_ratios": [1.55, 1.0], "hspace": 0.14}
)
fig.patch.set_facecolor(PAPER)

# Stress shading
stress_windows = [
    ("2011-05-01", "2012-06-01", "Euro Crisis"),
    ("2020-02-15", "2020-05-01", "COVID"),
    ("2022-01-01", "2022-12-31", "2022 Inflation Shock"),
]
for ax in (ax1, ax2):
    for s_dt, e_dt, lbl in stress_windows:
        ax.axvspan(pd.Timestamp(s_dt), pd.Timestamp(e_dt), color=SAND2, alpha=0.65, zorder=0)

# Resample to weekly for clean, fast SVG (<250KB) while keeping exact full-sample daily metrics in labels
nav_w = nav_df.resample("W-FRI").last()

# Panel 1: Log-scale Cumulative Wealth (Nov 2008 = 100)
ax1.plot(nav_w.index, nav_w["NAV_Stacked_Blend6040"], color=NAVY, lw=2.2,
         label="Stacked: 100% EFA + 100% 60/40 Trend/Macro (10.87% CAGR, 0.52 Sharpe)", zorder=5)
ax1.plot(nav_w.index, nav_w["NAV_Stacked_PureTrend"], color=SANDSTONE, lw=1.6, ls="--",
         label="Stacked: 100% EFA + 100% Pure Trend (9.44% CAGR, 0.46 Sharpe)", zorder=4)
ax1.plot(nav_w.index, nav_w["NAV_EFA"], color=RUST, lw=1.7,
         label="100% EFA Core Beta (7.52% CAGR, 0.40 Sharpe)", zorder=3)
ax1.plot(nav_w.index, nav_w["NAV_Split5050"], color=SAGE, lw=1.5, ls="-.",
         label="50/50 Unstacked Split (6.83% CAGR, 0.54 Sharpe)", zorder=3)

ax1.set_yscale("log")
ax1.set_yticks([75, 100, 150, 250, 400, 650])
ax1.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f"{int(y)}"))
from matplotlib.ticker import NullFormatter
ax1.yaxis.set_minor_formatter(NullFormatter())
ax1.set_ylabel("Indexed NAV (log scale, Nov 2008 = 100)", fontsize=9.5, labelpad=8)
ax1.grid(axis="y", color=BORDER, ls=":", lw=0.7, alpha=0.8)
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)
ax1.legend(loc="upper left", frameon=True, facecolor=PAPER, edgecolor=BORDER, fontsize=8.3)

ax1.set_ylim(70, 760)
# Annotate stress bands in clean space
for s_dt, e_dt, lbl in stress_windows:
    mid = pd.Timestamp(s_dt) + (pd.Timestamp(e_dt) - pd.Timestamp(s_dt)) / 2
    y_pos = 78 if lbl == "Euro Crisis" else 710
    va_pos = "bottom" if lbl == "Euro Crisis" else "top"
    ax1.text(mid, y_pos, lbl, ha="center", va=va_pos, fontsize=7.8, color=OCHRE, fontweight="bold")

ax1.set_title(
    "Return-Stacked International Equity + Global Macro/Trend vs. Unstacked Alternatives (2008–2026)",
    loc="left", fontsize=11.5, fontweight="bold", color=NAVY, pad=12
)

# Panel 2: Underwater Drawdowns
dd_stk = ((nav_df["NAV_Stacked_Blend6040"] / nav_df["NAV_Stacked_Blend6040"].cummax() - 1.0) * 100).resample("W-FRI").min()
dd_efa = ((nav_df["NAV_EFA"] / nav_df["NAV_EFA"].cummax() - 1.0) * 100).resample("W-FRI").min()
dd_trn = ((nav_df["NAV_Stacked_PureTrend"] / nav_df["NAV_Stacked_PureTrend"].cummax() - 1.0) * 100).resample("W-FRI").min()

ax2.fill_between(dd_efa.index, dd_efa, 0, color=RUST, alpha=0.14, zorder=2)
ax2.plot(dd_efa.index, dd_efa, color=RUST, lw=1.3, label="100% EFA Drawdown (Max -34.2%)", zorder=3)
ax2.plot(dd_trn.index, dd_trn, color=SANDSTONE, lw=1.2, ls="--", label="Stacked Pure Trend (Max -40.4%)", zorder=3)
ax2.plot(dd_stk.index, dd_stk, color=NAVY, lw=1.8, label="Stacked 60/40 Trend/Macro (Max -32.3%)", zorder=4)

# Callout 2022 drawdown protection
ax2.annotate(
    "2022 cushion:\n-9.8% vs. -28.7% EFA",
    xy=(pd.Timestamp("2022-09-30"), -9.8),
    xytext=(pd.Timestamp("2023-08-01"), -33.5),
    fontsize=8.2, color=NAVY, fontweight="bold",
    arrowprops=dict(arrowstyle="->", color=NAVY, lw=1.0),
    bbox=dict(boxstyle="square,pad=0.3", facecolor=PAPER, edgecolor=BORDER, lw=0.8),
)

ax2.set_ylabel("Drawdown (%)", fontsize=9.5, labelpad=8)
ax2.set_ylim(-45, 3)
ax2.grid(axis="y", color=BORDER, ls=":", lw=0.7, alpha=0.8)
ax2.spines["top"].set_visible(False)
ax2.spines["right"].set_visible(False)
ax2.legend(loc="lower left", frameon=True, facecolor=PAPER, edgecolor=BORDER, fontsize=8.0, ncol=3)
ax2.xaxis.set_major_locator(mdates.YearLocator(2))
ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

fig.text(
    0.06, 0.012,
    "Source: YAMF backtest on Yahoo Finance NYSE-aligned daily total-return data (Nov 3, 2008 – Nov 20, 2026; 4,541 days). Net of 5 bps/side overlay slippage and 40 bps/yr equity futures financing spread.",
    fontsize=7.6, color=MUTED
)
fig.subplots_adjust(left=0.075, right=0.98, top=0.92, bottom=0.085)
fig.savefig(os.path.join(OUT_PUB, "portable-alpha-backtest.svg"), format="svg")
fig.savefig("/tmp/portable-alpha-backtest.png", dpi=150)
plt.close(fig)

# --- EXHIBIT 2: Macro/Trend Weight Sweep & Multi-Asset Cumulative Attribution (portable-alpha-signals.svg) ---
fig, (axL, axR) = plt.subplots(1, 2, figsize=(11.2, 4.7), gridspec_kw={"wspace": 0.28})
fig.patch.set_facecolor(PAPER)

# Left Panel: Weight Sweep (Overlay Sharpe vs Stacked Max Drawdown)
x_w = sweep_df["macro_pct"]
l1 = axL.plot(x_w, sweep_df["ov_sharpe"], color=NAVY, marker="o", ms=5.5, lw=2.2, label="Overlay Sharpe (left)")
axL.axvspan(35, 55, color=SAND2, alpha=0.7, zorder=0)
axL.text(45, 0.356, "Sweet spot\n(40–50% Macro)", ha="center", va="center", fontsize=8.0, color=OCHRE, fontweight="bold")
axL.set_xlabel("Global Macro Weight in Overlay (% Macro / Remainder = Trend)", fontsize=8.8)
axL.set_ylabel("Standalone Overlay Sharpe Ratio", fontsize=9.0, color=NAVY)
axL.set_ylim(0.25, 0.45)
axL.set_xlim(-3, 103)
axL.grid(axis="y", color=BORDER, ls=":", lw=0.7, alpha=0.8)
axL.spines["top"].set_visible(False)

axL2 = axL.twinx()
l2 = axL2.plot(x_w, sweep_df["stk_mdd_pct"].abs(), color=RUST, marker="s", ms=4.8, lw=1.8, ls="--",
               label="Stacked Max Drawdown |%| (right)")
axL2.axhline(34.19, color=MUTED, ls=":", lw=1.1, label="100% EFA Max DD (34.2%)")
axL2.set_ylabel("Stacked Portfolio Max Drawdown (%)", fontsize=9.0, color=RUST)
axL2.set_ylim(29, 43)
axL2.spines["top"].set_visible(False)

lines = l1 + l2 + [axL2.lines[-1]]
labels = [ln.get_label() for ln in lines]
axL.legend(lines, labels, loc="upper right", frameon=True, facecolor=PAPER, edgecolor=BORDER, fontsize=7.5)
axL.set_title("A. Macro vs. Trend Weight Frontier", loc="left", fontsize=10.5, fontweight="bold", color=NAVY, pad=10)

# Right Panel: Cumulative Multi-Asset Gross P&L Attribution (60/40 Overlay)
cls_colors = {
    "Commodities": OCHRE,
    "Rates": NAVY,
    "FX": SAGE,
    "Equities": SANDSTONE,
}
for cls, col in cls_colors.items():
    cum_pct = (res_blend["cls_contrib"].loc[EVAL_START:, cls].cumsum() * 100.0).resample("W-FRI").last()
    axR.plot(cum_pct.index, cum_pct, color=col, lw=1.9, label=f"{cls} ({cum_pct.iloc[-1]:+.1f}% cum.)")

axR.axhline(0, color=BORDER, lw=1.0)
axR.axvspan(pd.Timestamp("2022-01-01"), pd.Timestamp("2022-12-31"), color=SAND2, alpha=0.65, zorder=0)
axR.set_ylim(-6, 39.5)
axR.text(pd.Timestamp("2022-07-01"), 38.2, "2022", ha="center", va="top", fontsize=7.8, color=OCHRE, fontweight="bold")
axR.set_ylabel("Cumulative Gross Excess Return (%)", fontsize=9.0)
axR.set_xlabel("Year (2008–2026)", fontsize=8.8)
axR.grid(axis="y", color=BORDER, ls=":", lw=0.7, alpha=0.8)
axR.spines["top"].set_visible(False)
axR.spines["right"].set_visible(False)
axR.legend(loc="upper left", frameon=True, facecolor=PAPER, edgecolor=BORDER, fontsize=7.8)
axR.xaxis.set_major_locator(mdates.YearLocator(3))
axR.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
axR.set_title("B. Multi-Asset Sleeve Attribution (60/40 Overlay)", loc="left", fontsize=10.5, fontweight="bold", color=NAVY, pad=10)

fig.text(
    0.055, 0.015,
    "Source: YAMF backtest on 16 liquid multi-asset ETFs converted to unfunded futures excess returns (R_ETF - R_BIL), Nov 2008 – Nov 2026. Equal 25% risk budget per asset class.",
    fontsize=7.6, color=MUTED
)
fig.subplots_adjust(left=0.075, right=0.97, top=0.88, bottom=0.16)
fig.savefig(os.path.join(OUT_PUB, "portable-alpha-signals.svg"), format="svg")
fig.savefig("/tmp/portable-alpha-signals.png", dpi=150)
plt.close(fig)

print("Generated SVGs, CSV, and ZIP successfully.")
