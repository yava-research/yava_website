YAMF Quantitative Strategy Replication Package
==============================================
Article: Cross-Sectional Statistical Arbitrage & Lead-Lag Dynamics in Educational Publishing
Universe: RELX, PSO, WLY, MH, SCHL (hedges/FX: SPY, IWM, GBPUSD=X)
Sample:   2021-11-15 through 2026-11-13 (Yahoo Finance daily split/dividend-adjusted closes)

Contents:
  - backtest_educational_services.py : Self-contained causal backtest engine
  - summary_metrics.json             : Full-sample and 5-stock post-MH performance & attribution

Run Instructions:
  uv run --with numpy --with pandas --with yfinance python3 backtest_educational_services.py
