#!/usr/bin/env python3
"""
YAMF Quantitative Research — Educational Services Basket Backtest
Universe: RELX, PSO, WLY, MH, SCHL (+ SPY, IWM, GBPUSD=X hedges/adjustments)

Reproduces:
  1. Baseline 60-Day Rolling OLS Residual Mean Reversion + Institutional Lead-Lag
  2. State-Space Kalman Filter Dynamic Hedging + Calendar Seasonality + SCHL Correlation Gate

Run with:
  uv run --with numpy --with pandas --with yfinance python3 backtest_educational_services.py
"""
import json, urllib.request, datetime, warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import yfinance as yf


def fetch_yahoo_series(tickers, period_range="5y"):
    prices = {}
    for t in tickers:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.request.quote(t)}?interval=1d&range={period_range}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            res = json.loads(resp.read().decode())["chart"]["result"][0]
        ts = res["timestamp"]
        quote = res["indicators"]["quote"][0]
        adj = res["indicators"].get("adjclose", [{}])[0].get("adjclose", quote["close"])
        dates = [datetime.datetime.fromtimestamp(x, datetime.timezone.utc).strftime("%Y-%m-%d") for x in ts]
        s_adj = pd.Series(adj, index=pd.to_datetime(dates), dtype=float)
        prices[t] = s_adj[~s_adj.index.duplicated(keep="last")]
    return prices


def fetch_earnings_mask(idx, stocks):
    mask = pd.DataFrame(False, index=idx, columns=stocks)
    pairs = [(s, s) for s in stocks] + [("REL.L", "RELX"), ("PSON.L", "PSO")]
    for sym, col in pairs:
        try:
            ed = yf.Ticker(sym).earnings_dates
            if ed is not None and len(ed) > 0:
                for d in pd.to_datetime([x.date() for x in ed.index]):
                    pos = idx.searchsorted(d)
                    for off in (-2, -1, 0, 1):
                        if 0 <= pos + off < len(idx):
                            mask.iloc[pos + off, mask.columns.get_loc(col)] = True
        except Exception:
            pass
    return mask


def run_pipeline():
    tickers = ["RELX", "PSO", "WLY", "MH", "SCHL", "SPY", "IWM", "GBPUSD=X"]
    stocks = ["RELX", "PSO", "WLY", "MH", "SCHL"]
    prices = fetch_yahoo_series(tickers)
    idx = prices["SPY"].dropna().index
    df_p = pd.DataFrame({t: prices[t].reindex(idx) for t in tickers})
    df_p["GBPUSD=X"] = df_p["GBPUSD=X"].ffill()

    rets_usd = df_p[stocks + ["SPY", "IWM"]].pct_change()
    fx_ret = df_p["GBPUSD=X"].pct_change().fillna(0.0)
    rets_sig = rets_usd[stocks].copy()
    for uk in ("RELX", "PSO"):
        rets_sig[uk] = (1.0 + rets_usd[uk]) / (1.0 + fx_ret) - 1.0

    earnings_mask = fetch_earnings_mask(idx, stocks)
    bmk_w = {"RELX": 0.45, "PSO": 0.30, "WLY": 0.15, "MH": 0.10}
    one_way_cost = {"RELX": 0.00025, "PSO": 0.00025, "WLY": 0.000625, "MH": 0.000625, "SCHL": 0.00150, "SPY": 0.00005, "IWM": 0.00010}

    loo_ret = {}
    for s in stocks:
        sr = pd.Series(0.0, index=idx)
        for dt in idx:
            avail = {k: v for k, v in bmk_w.items() if k != s and pd.notna(rets_sig.loc[dt, k])}
            tot = sum(avail.values())
            sr.loc[dt] = sum((v / tot) * rets_sig.loc[dt, k] for k, v in avail.items()) if tot > 0 else np.nan
        loo_ret[s] = sr

    # Online Kalman State-Space Filter
    eps_kf = pd.DataFrame(np.nan, index=idx, columns=stocks)
    beta_spy_kf = pd.DataFrame(0.0, index=idx, columns=stocks)
    beta_iwm_kf = pd.DataFrame(0.0, index=idx, columns=stocks)

    for s in stocks:
        use_iwm = (s == "SCHL")
        y_all = rets_sig[s].values
        x1_all = loo_ret[s].values
        x2_all = (rets_usd["IWM"] if use_iwm else rets_usd["SPY"]).values
        theta = np.array([0.0, 0.5, 0.5])
        P = np.eye(3) * 0.2
        Q = np.diag([1e-7, 1.5e-4, 1.5e-4])
        R_var = 0.02 ** 2
        active = 0
        for t in range(1, len(idx)):
            if np.isnan(y_all[t]) or np.isnan(x1_all[t]) or np.isnan(x2_all[t]):
                continue
            active += 1
            F = np.array([1.0, x1_all[t], x2_all[t]])
            P_pred = P + Q
            innov = y_all[t] - float(F @ theta)
            S_t = float(F @ P_pred @ F.T) + R_var
            K = (P_pred @ F) / S_t
            theta = theta + K * innov
            P = (np.eye(3) - np.outer(K, F)) @ P_pred
            R_var = 0.96 * R_var + 0.04 * (innov ** 2)
            if active >= 30:
                eps_kf.iloc[t, eps_kf.columns.get_loc(s)] = innov
                if use_iwm:
                    beta_iwm_kf.iloc[t, beta_iwm_kf.columns.get_loc(s)] = theta[2]
                    beta_spy_kf.iloc[t, beta_spy_kf.columns.get_loc(s)] = theta[1] * 0.32
                else:
                    beta_spy_kf.iloc[t, beta_spy_kf.columns.get_loc(s)] = theta[2] + theta[1] * 0.32

    vol20 = rets_sig.rolling(20).std()
    z_mr_kf = -(eps_kf.rolling(5).sum() / eps_kf.rolling(5).sum().rolling(20).std())
    ret3d = rets_sig.rolling(3).sum()
    leader = 0.5 * (ret3d["RELX"] / vol20["RELX"] + ret3d["PSO"] / vol20["PSO"])
    z_ll = pd.DataFrame(0.0, index=idx, columns=stocks)
    for s in ("WLY", "MH", "SCHL"):
        z_ll[s] = leader - (ret3d[s] / vol20[s])

    shock_freeze = (rets_sig.abs() > 3.5 * vol20).rolling(5, min_periods=1).max().astype(bool)
    schl_corr60 = rets_sig["SCHL"].rolling(60).corr(loo_ret["SCHL"])

    start_idx = 85
    w_curr = pd.Series(0.0, index=stocks)
    w_spy_c, w_iwm_c = 0.0, 0.0
    gross_l, net_l, turn_l = [], [], []

    for t in range(start_idx, len(idx) - 1):
        dt = idx[t]
        month = dt.month
        sig_vol = vol20.iloc[t]
        blocked = earnings_mask.iloc[t] | shock_freeze.iloc[t]

        comp = (0.60 * z_mr_kf.iloc[t] + 0.40 * z_ll.iloc[t]).copy()
        if month in (7, 9, 12):
            comp["SCHL"] *= 0.35
        if pd.notna(schl_corr60.iloc[t]) and schl_corr60.iloc[t] < 0.15:
            comp["SCHL"] = 0.0
        if month in (8, 9, 10, 11):
            for nm in ("MH", "PSO"):
                if pd.notna(comp[nm]) and comp[nm] < 0:
                    comp[nm] *= 0.50

        valid = comp.notna() & sig_vol.notna() & (sig_vol > 0) & (~blocked)
        w_target = pd.Series(0.0, index=stocks)
        if valid.sum() >= 2:
            c_dem = comp[valid] - comp[valid].mean()
            if c_dem.abs().max() >= 0.80:
                raw = c_dem / sig_vol[valid]
                if raw.abs().sum() > 1e-12:
                    w = raw / raw.abs().sum()
                    caps = pd.Series({"RELX": 0.35, "PSO": 0.35, "WLY": 0.35, "MH": 0.35, "SCHL": 0.15})
                    for _ in range(8):
                        w = w.clip(lower=-caps[valid], upper=caps[valid])
                        w = w - w.mean()
                        if w.abs().sum() > 1.0:
                            w = w / w.abs().sum()
                    w_target[valid] = w

        w_next = w_curr.copy()
        for s in stocks:
            if blocked[s] or pd.isna(rets_sig.iloc[t][s]):
                w_next[s] = 0.0
            elif w_target.abs().sum() == 0 and comp.loc[s] * w_curr[s] > 0:
                w_next[s] = w_curr[s]
            elif abs(w_target[s] - w_curr[s]) > 0.12:
                w_next[s] = w_target[s]
        nz = w_next != 0
        if nz.sum() >= 2:
            w_next[nz] -= w_next[nz].mean()
        else:
            w_next[:] = 0.0

        net_b_spy = float((w_next * beta_spy_kf.iloc[t]).sum())
        w_spy_n = -net_b_spy if abs(net_b_spy) > 0.10 else 0.0
        net_b_iwm = float((w_next * beta_iwm_kf.iloc[t]).sum())
        w_iwm_n = -net_b_iwm if abs(net_b_iwm) > 0.05 else 0.0

        trades = (w_next - w_curr).abs()
        tc = sum(trades[s] * one_way_cost[s] for s in stocks) + abs(w_spy_n - w_spy_c) * one_way_cost["SPY"] + abs(w_iwm_n - w_iwm_c) * one_way_cost["IWM"]
        r_next = rets_usd.iloc[t + 1]
        g_ret = sum(w_next[s] * (0.0 if pd.isna(r_next[s]) else float(r_next[s])) for s in stocks) + w_spy_n * float(r_next["SPY"]) + w_iwm_n * float(r_next["IWM"])
        n_ret = g_ret - tc
        turn = float(trades.sum() + abs(w_spy_n - w_spy_c) + abs(w_iwm_n - w_iwm_c))

        w_curr, w_spy_c, w_iwm_c = w_next, w_spy_n, w_iwm_n
        gross_l.append(g_ret)
        net_l.append(n_ret)
        turn_l.append(turn)

    res = pd.DataFrame({"gross": gross_l, "net": net_l, "turnover": turn_l}, index=idx[start_idx + 1:])
    sub5 = res.loc["2025-09-15":]
    print("5-Stock Post-MH Annualized Gross:", round(((1 + sub5["gross"]).prod() ** (252 / len(sub5)) - 1) * 100, 2), "%")
    print("5-Stock Post-MH Annualized Net:  ", round(((1 + sub5["net"]).prod() ** (252 / len(sub5)) - 1) * 100, 2), "%")
    print("5-Stock Post-MH Net Sharpe:      ", round((sub5["net"].mean() / sub5["net"].std()) * np.sqrt(252), 2))


if __name__ == "__main__":
    run_pipeline()
